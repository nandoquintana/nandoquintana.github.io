# Zope modules
from OFS.Folder import Folder
from AccessControl import ClassSecurityInfo

# Modules from other products
from Products.PageTemplates.PageTemplateFile import PageTemplateFile

add_form = PageTemplateFile('www/add_form.pt',globals())

def add(self, id, title, REQUEST=None):
    """ action of add_form """
    self._setObject(id, MiCarpeta(id, title))
    return 'Ok.'
    
class MiCarpeta(Folder):
      """ A Folder """
      
      meta_type = 'Mi Carpeta'
      security = ClassSecurityInfo()

      def __init__(self, id, title): 
		""" init"""
		self.id = id
		self.title = title
		MiCarpeta.__bases__[-1].__init__(self, id=id)
      
      security.declareProtected('View','index_html')

      def index_html(self,REQUEST=None,RESPONSE=None):
		  """ view """
		  return "La carpeta '"  +str(self.id)+    "', " + "se titula '" +str(self.title)+ "'."

      security.declareProtected('View','manage_edit')
      def manage_edit(self,REQUEST=None,RESPONSE=None):
          """ edit """
          self.manage_editProperties(REQUEST)
      
      edit_form = PageTemplateFile('www/edit_form.pt',globals())
