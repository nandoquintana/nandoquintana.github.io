import micarpeta

def initialize(context):
    """ add to the product list """
    context.registerClass(
        micarpeta.MiCarpeta,
        constructors = (micarpeta.add_form,
                        micarpeta.add),
        icon='img/book.png')